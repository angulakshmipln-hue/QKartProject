package test;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PageValidationTest extends BaseTest {

    @Test
    public void verifyPageDetails() {
        String placeholder = driver.findElement(By.name("search")).getAttribute("placeholder");
        Assert.assertEquals(placeholder, "Search for items/categories");

        Assert.assertEquals(driver.getTitle(), "QKart");
        Assert.assertTrue(driver.getCurrentUrl().contains("https"));
    }
}
