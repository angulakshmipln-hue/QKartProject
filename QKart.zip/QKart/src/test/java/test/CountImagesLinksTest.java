package test;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class CountImagesLinksTest extends BaseTest {

    @Test
    public void countImagesAndLinks() {
        int images = driver.findElements(By.tagName("img")).size();
        int links = driver.findElements(By.tagName("a")).size();

        System.out.println("Total Images: " + images);
        System.out.println("Total Links: " + links);
    }
}
