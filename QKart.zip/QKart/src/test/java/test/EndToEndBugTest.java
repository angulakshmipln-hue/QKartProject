package test;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;



public class EndToEndBugTest  {

	@Test
	public void EndtoEndTest() throws InterruptedException
	{

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        // ====================================================    
        //1.) Login to application URL
        // ====================================================   
        
        driver.get("https://crio-qkart-frontend-qa.vercel.app/");

        // -------- FLUENT WAIT --------
        FluentWait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(25))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(Exception.class);

        // ====================================================
        // 2.) Register using username and password
        // ====================================================

        // Click Register
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='Register']"))).click();

        // Create unique username
        String username = "angukart" + System.currentTimeMillis();
        System.out.println("Username is: " + username);

        // Enter details
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")))
                .sendKeys(username);

        driver.findElement(By.id("password"))
                .sendKeys("Test@123456");

        driver.findElement(By.id("confirmPassword"))
                .sendKeys("Test@123456");

        // Click Register Now
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='Register Now']")))
                .click();

        // Capture Register Message
        WebElement successMsg = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//div[@role='alert']")
                ));

        System.out.println("Register Message: " + successMsg.getText());
        
        wait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.id("notistack-snackbar")));
         // ====================================================
        // 3.) Login using username and password
        // ====================================================

   

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")))
                .sendKeys(username);

        driver.findElement(By.id("password")).sendKeys("Test@123456");

        driver.findElement(By.xpath("//button[text()='Login to QKart']")) .click();

        // Verify Login notistack-snackbar
       
        WebElement loginMsg = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.id("notistack-snackbar")));

        System.out.println("Login Message: " + loginMsg.getText());

        // wait until toast disappears
        //wait.until(ExpectedConditions.invisibilityOfElementLocated(
            //    By.id("notistack-snackbar")));
        Thread.sleep(3000);
        
        

     // =============================
     // 4.)Add  yonex  rackquet in cart by clicking on Add to cart button 
     // =============================

        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));

     // get all buttons
     List<WebElement> addToCartBtn = wait1.until(
             ExpectedConditions.visibilityOfAllElementsLocatedBy(
                     By.xpath("//button[contains(@class,'MuiButton-root')]")
             )
     );

     // select 3rd button
     WebElement btn = addToCartBtn.get(3);

     // scroll to element (prevents click intercepted error)
     ((JavascriptExecutor) driver)
             .executeScript("arguments[0].scrollIntoView(true);", btn);

    
     Thread.sleep(500);
     //First click
     btn.click();
     Thread.sleep(5000);
   //Second click
     btn.click();
     
     // =============================
     //5.) validate the message “ Product has been successfully added to cart”.
     //  6.) Try clicking “ Add to Cart “ Button again and validate the message” Item Already Added in cart use the cart 
    // sidebar to update and delete the item”.
     // =============================

    
     WebElement cartMsg = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.id("notistack-snackbar")));

     System.out.println("Cart Message: " + cartMsg.getText());

    

     // wait toast disappear (important)
     wait.until(ExpectedConditions.invisibilityOfElementLocated(
             By.id("notistack-snackbar")));
     
     // =============================
     //6.) Add Roadster Mens Running Shoes and pick size from the dropdown menu
    // =============================
     
     //select size from dropdown

     WebElement shoesize = driver.findElement(By.id("uncontrolled-native"));

     Select s = new Select(shoesize);

     s.selectByVisibleText("8");
    
     Thread.sleep(500);
     // =============================
     // 5.) Add Roadster Mens Running Shoes and pick size from the dropdown menu
     // =============================

  

     WebElement roadstershoebtn = addToCartBtn.get(5);

     // scroll to element (prevents click intercepted error)
     ((JavascriptExecutor) driver)
             .executeScript("arguments[0].scrollIntoView(true);", roadstershoebtn);

     Thread.sleep(500);
     roadstershoebtn.click();
  // =============================
     // 6.) Validate the cart items
     // =============================
     
  
     // cart item -Yonex
     WebElement cartItem1 = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//div[@class='cart MuiBox-root css-0']//*[contains(text(),'YONEX')]")
             )
     );

     // validation
     if (cartItem1.isDisplayed()) {
         System.out.println("✅ YONEX Smash Badminton Racquetadded successfully to cart");
     } else {
         System.out.println("❌ Item not added");
     }

  // cart item -Roadster
     WebElement cartItem2 = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//div[@class='cart MuiBox-root css-0']//*[contains(text(),'Roadster')]")
             )
     );

     // validation
     if (cartItem2.isDisplayed()) {
         System.out.println("✅ Roadster Shoes added successfully to cart");
     } else {
         System.out.println("❌ Item not added");
     }
  // =============================
     // 7.) Click on checkout button.
     // =============================

     WebElement checkout = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//*[@class='MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButtonBase-root checkout-btn css-177pwqq']")));
     checkout.click();
     
  // ================================================
     //  8.) Verify the title of the next webpage 
     // ===========================================
     String currentURL = driver.getCurrentUrl();
     System.out.println("Current URL: " + currentURL);
     if (currentURL.contains("checkout"))
     {
    	 System.out.println("Landing Page is correct");
     }
     else 
     {
    	 System.out.println("Landing Page is not correct");
     }
     
  // ================================================
     //   9.) Click on add new Address and type the respective addresses 
     // ===========================================
     WebElement addaddress = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//*[@class='MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeLarge MuiButton-containedSizeLarge MuiButtonBase-root  css-rfvjbl']")));
     addaddress.click();
     
     
     WebElement typeaddress = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//*[@placeholder='Enter your complete address']")));
     typeaddress.sendKeys("Test Street,chennai-600073");
     
  // ================================================
     //  10.) click on ADD button and verify the address entered is displayed
     // ===========================================
     
     WebElement add = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//*[@class='MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButtonBase-root  css-177pwqq']")));
     add.click();
     
     Thread.sleep(5000);    
  // ================================================
     //  11.)click on delete button to remove one address.
     // ===========================================
     WebElement selectaddress = driver.findElement(
                     By.xpath("//input[@type='radio']"));
     
     ((JavascriptExecutor) driver)
     .executeScript("arguments[0].click();", selectaddress);

     //selectaddress.click();
     
     WebElement delete = wait.until(
             ExpectedConditions.visibilityOfElementLocated(
                     By.xpath("//button[@class='MuiButton-root MuiButton-outlined MuiButton-outlinedPrimary MuiButton-sizeMedium MuiButton-outlinedSizeMedium MuiButtonBase-root  css-1987zji']")));
     delete.click();
     driver.close();  
    } 
}
