package test;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UIValidationTest extends BaseTest {

    @Test
    public void verifyUIElements() {
        Assert.assertTrue(driver.findElement(By.xpath("//button[text()='Login']")).isDisplayed());
        Assert.assertTrue(driver.findElement(By.xpath("//button[text()='Register']")).isDisplayed());
        Assert.assertTrue(driver.findElement(By.name("search")).isDisplayed());
    }
}
