package test;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void loginTest() {
        driver.findElement(By.xpath("//button[text()='Login']")).click();

        driver.findElement(By.id("username")).sendKeys("admin123");
        driver.findElement(By.id("password")).sendKeys("admin123");
        driver.findElement(By.xpath("//button[contains(text(),'Login to QKart')]")).click();

        boolean logoutDisplayed = driver.findElement(By.xpath("//button[text()='Logout']")).isDisplayed();
        Assert.assertTrue(logoutDisplayed);
    }
}
